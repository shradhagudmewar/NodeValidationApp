
const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

// Escape user input before displaying it in HTML
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// Display registration form using GET
app.get("/", (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Student Registration</title>
            <link rel="stylesheet" href="/style.css">
        </head>
        <body>
            <div class="container">
                <h1>Student Registration</h1>
                <p>Enter your details to register.</p>

                <form action="/register" method="POST">
                    <label>Full Name</label>
                    <input type="text" name="name"
                           placeholder="Enter your name" required>

                    <label>Email</label>
                    <input type="email" name="email"
                           placeholder="Enter your email" required>

                    <label>Age</label>
                    <input type="number" name="age"
                           placeholder="Enter your age" required>

                    <label>Course</label>
                    <select name="course" required>
                        <option value="">Select a course</option>
                        <option value="Computer Engineering">Computer Engineering</option>
                        <option value="IT">Information Technology</option>
                        <option value="Electronics">Electronics</option>
                    </select>

                    <button type="submit">Register</button>
                </form>
            </div>
        </body>
        </html>
    `);
});

// Process submitted data using POST
app.post("/register", (req, res) => {
    const { name, email, age, course } = req.body;
    const errors = [];

    // Server-side validation
    if (typeof name !== "string" ||
        name.trim().length < 3 ||
        name.trim().length > 50 ||
        !/^[A-Za-z ]+$/.test(name.trim())) {
        errors.push("Name must contain 3-50 letters and spaces only.");
    }

    if (typeof email !== "string" ||
        email.length > 254 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push("Please enter a valid email address.");
    }

    const studentAge = Number(age);

    if (age === undefined || age.trim() === "" ||
        !Number.isInteger(studentAge) ||
        studentAge < 16 || studentAge > 60) {
        errors.push("Age must be a whole number between 16 and 60.");
    }

    const validCourses = [
        "Computer Engineering",
        "IT",
        "Electronics"
    ];

    if (typeof course !== "string" ||
        !validCourses.includes(course)) {
        errors.push("Please select a valid course.");
    }

    // Display errors if validation fails
    if (errors.length > 0) {
        return res.status(400).send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Validation Error</title>
                <link rel="stylesheet" href="/style.css">
            </head>
            <body>
                <div class="container">
                    <h1>Registration Failed</h1>
                    <div class="error">
                        <strong>Please correct these errors:</strong>
                        <ul>
                            ${errors.map(error =>
                                `<li>${escapeHTML(error)}</li>`
                            ).join("")}
                        </ul>
                    </div>
                    <a href="/">Go Back to Form</a>
                </div>
            </body>
            </html>
        `);
    }

    // Display success message for valid input
    res.status(200).send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Registration Successful</title>
            <link rel="stylesheet" href="/style.css">
        </head>
        <body>
            <div class="container">
                <h1>Registration Successful!</h1>
                <p class="success">Your details have passed server-side validation.</p>

                <h3>Submitted Details</h3>
                <p><strong>Name:</strong> ${escapeHTML(name.trim())}</p>
                <p><strong>Email:</strong> ${escapeHTML(email)}</p>
                <p><strong>Age:</strong> ${studentAge}</p>
                <p><strong>Course:</strong> ${escapeHTML(course)}</p>

                <a href="/">Register Another Student</a>
            </div>
        </body>
        </html>
    `);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
